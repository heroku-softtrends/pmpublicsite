﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PMPublicSite.ViewModels
{
    public class CategoryViewModel
    {
        public string categoryName { get; set; }
        public string categoryId { get; set; }
        public string description { get; set; }
    }
}
