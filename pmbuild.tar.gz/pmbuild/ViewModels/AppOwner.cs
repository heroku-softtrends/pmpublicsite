﻿

namespace PMPublicSite.ViewModels
{
    public class AppOwner
    {
        public string email { get; set; }
        public string id { get; set; }
    }
}
