﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PMPublicSite.ViewModels
{
    public class ApplicationViewModel
    {
        public string app_id { get; set; }
        public string heroku_app_id { get; set; }
        public string app_name { get; set; }
        public string app_alias_name { get; set; }
        public string app_json { get; set; }
        public DateTime created_at { get; set; }
        public DateTime updated_at { get; set; }
        public string app_access { get; set; }
        public string category_id { get; set; }
        public string web_url { get; set; }
    }
}
