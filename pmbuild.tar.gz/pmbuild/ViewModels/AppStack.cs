﻿

namespace PMPublicSite.ViewModels
{
    public class AppStack
    {
        public string id { get; set; }
        public string name { get; set; }
    }
}
