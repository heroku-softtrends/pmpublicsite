﻿
namespace PMPublicSite.ViewModels
{
    public class AccountIdentityProvider
    {
        public string id { get; set; }
        public AccountOrganization organization { get; set; }
    }
}
