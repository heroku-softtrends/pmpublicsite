﻿

namespace PMPublicSite.ViewModels
{
    public class AppRegion
    {
        public string id { get; set; }
        public string name { get; set; }
    }
}
