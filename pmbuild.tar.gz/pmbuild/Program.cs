﻿using System.IO;
using Microsoft.AspNetCore.Hosting;
using PMPublicSite.Helpers;

namespace PMPublicSite
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var hostBuilder = new WebHostBuilder()
              .UseKestrel()
              .UseContentRoot(Directory.GetCurrentDirectory())
              .UseIISIntegration()
              .UseStartup<Startup>();

            //Get environment port if it has assigned else dotnet core runtime will assign 5000 as defult port
            var port = Utilities.GetEnvVarVal("PORT");
            if (!string.IsNullOrEmpty(port))
            {
                hostBuilder.UseUrls(string.Format("http://*:{0}", port));
            }

            var host = hostBuilder.Build();
            host.Run();
        }
    }
}
