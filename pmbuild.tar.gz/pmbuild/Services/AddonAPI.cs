﻿using RestSharp;
using PMPublicSite.Helpers;
using System;
using System.Collections.Generic;
using System.Net;
using System.Threading;
using PMPublicSite.ViewModels;

namespace PMPublicSite.Services
{
    public static class AddonAPI
    {
        private static IRequestFactory mFactory { get; set; }

        static AddonAPI()
        {
            mFactory = new RequestFactory();
        }

        public static List<CategoryViewModel> GetCategoryInfo(string id)
        {
            var request = mFactory.CreateRequest();
            request.Resource = $"public/getpubliccategories/{id}";
            request.Method = Method.GET;
            request.AddHeader("content-type", "application/json");
            var blocker = new AutoResetEvent(false);

            IRestResponse httpResponse = null;
            var client = mFactory.CreateClient();
            client.BaseUrl = new Uri(ConfigVars.Instance.AddonAPIUrl);
            client.ExecuteAsync(request, response =>
            {
                httpResponse = response;
                blocker.Set();
            });
            blocker.WaitOne();

            if (httpResponse != null && (httpResponse.StatusCode == HttpStatusCode.OK || httpResponse.StatusCode == HttpStatusCode.Created))
            {
                return (new RestSharp.Deserializers.JsonDeserializer()).Deserialize<List<CategoryViewModel>>(httpResponse);
            }
            return null;
        }

        public static ResourceViewModel GetResource(string id)
        {
            var request = mFactory.CreateRequest();
            request.Resource = $"public/getresource/{id}";
            request.Method = Method.GET;
            request.AddHeader("content-type", "application/json");
            var blocker = new AutoResetEvent(false);

            IRestResponse httpResponse = null;
            var client = mFactory.CreateClient();
            client.BaseUrl = new Uri(ConfigVars.Instance.AddonAPIUrl);
            client.ExecuteAsync(request, response =>
            {
                httpResponse = response;
                blocker.Set();
            });
            blocker.WaitOne();

            if (httpResponse != null && (httpResponse.StatusCode == HttpStatusCode.OK || httpResponse.StatusCode == HttpStatusCode.Created))
            {
                return (new RestSharp.Deserializers.JsonDeserializer()).Deserialize<ResourceViewModel>(httpResponse);
            }
            return default(ResourceViewModel);
        }

        public static List<ApplicationViewModel> GetAppList(string id)
        {
            var request = mFactory.CreateRequest();
            request.Resource = $"public/getpublicapps/{id}";
            request.Method = Method.GET;
            request.AddHeader("content-type", "application/json");
            var blocker = new AutoResetEvent(false);

            IRestResponse httpResponse = null;
            var client = mFactory.CreateClient();
            client.BaseUrl = new Uri(ConfigVars.Instance.AddonAPIUrl);
            client.ExecuteAsync(request, response =>
            {
                httpResponse = response;
                blocker.Set();
            });
            blocker.WaitOne();

            if (httpResponse != null && (httpResponse.StatusCode == HttpStatusCode.OK || httpResponse.StatusCode == HttpStatusCode.Created))
            {
                return (new RestSharp.Deserializers.JsonDeserializer()).Deserialize<List<ApplicationViewModel>>(httpResponse);
            }
            return null;
        }

        public static ApplicationViewModel GetAppDetail(string id)
        {
            var request = mFactory.CreateRequest();
            request.Resource = $"public/getappdetail/{id}";
            request.Method = Method.GET;
            request.AddHeader("content-type", "application/json");
            var blocker = new AutoResetEvent(false);

            IRestResponse httpResponse = null;
            var client = mFactory.CreateClient();
            client.BaseUrl = new Uri(ConfigVars.Instance.AddonAPIUrl);
            client.ExecuteAsync(request, response =>
            {
                httpResponse = response;
                blocker.Set();
            });
            blocker.WaitOne();

            if (httpResponse != null && (httpResponse.StatusCode == HttpStatusCode.OK || httpResponse.StatusCode == HttpStatusCode.Created))
            {
                return (new RestSharp.Deserializers.JsonDeserializer()).Deserialize<ApplicationViewModel>(httpResponse);
            }
            return null;
        }
    }
}
