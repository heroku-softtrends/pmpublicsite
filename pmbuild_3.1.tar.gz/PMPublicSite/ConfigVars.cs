﻿using System;

namespace PMPublicSite
{
    public sealed class ConfigVars
    {
        public string AddonAPIUrl = string.Empty;
        public string ResourceId = string.Empty;

        private ConfigVars()
        {
            ResourceId = Environment.GetEnvironmentVariable("ResourceId");
            AddonAPIUrl = Environment.GetEnvironmentVariable("AddonAPIUrl");

            //ResourceId = "5de37aff-1274-49f2-b925-a44dfab335b3";
            //AddonAPIUrl = "https://pmpwa-new.herokuapp.com";
        }

        public static ConfigVars Instance { get { return ConfigVarInstance.Instance; } }

        private class ConfigVarInstance
        {
            static ConfigVarInstance()
            {
            }

            internal static readonly ConfigVars Instance = new ConfigVars();
        }
    }
}
