using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace PMPublicSite
{
    public class Program
    {
        public static void Main(string[] args)
        {
            CreateWebHostBuilder(args).Build().Run();
        }

        public static IWebHostBuilder CreateWebHostBuilder(string[] args) =>
            WebHost.CreateDefaultBuilder(args)
            .ConfigureLogging((hostingContext, logging) =>
            {
                logging.AddConfiguration(hostingContext.Configuration.GetSection("Logging"));
                logging.AddFilter("Microsoft", LogLevel.None)
                       .AddFilter("System", LogLevel.None)
                       .AddFilter("Hangfire", LogLevel.None)
                       .AddConsole(options => options.IncludeScopes = true);
                logging.AddFilter("Microsoft", LogLevel.None)
                       .AddFilter("System", LogLevel.None)
                       .AddFilter("Hangfire", LogLevel.None)
                       .AddDebug();
            })
            .ConfigureKestrel((context, options) =>
            {
                // Set properties and call methods on options
                options.Limits.MaxRequestBodySize = Int32.MaxValue;
                options.Limits.MaxRequestBufferSize = Int32.MaxValue;
                options.Limits.MaxResponseBufferSize = Int32.MaxValue;
                options.Limits.KeepAliveTimeout = TimeSpan.FromMinutes(5);
            })
            .UseStartup<Startup>();
    }
}
