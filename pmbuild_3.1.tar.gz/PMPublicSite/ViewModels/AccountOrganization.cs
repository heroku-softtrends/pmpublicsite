﻿
namespace PMPublicSite.ViewModels
{
    public class AccountOrganization
    {
        public string name { get; set; }
    }
}
