﻿
namespace PMPublicSite.ViewModels
{
    public class AppBuildStack
    {
        public string id { get; set; }
        public string name { get; set; }
    }
}
