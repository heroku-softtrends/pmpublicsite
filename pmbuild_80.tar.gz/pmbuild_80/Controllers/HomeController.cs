﻿using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using PMPublicSite.ViewModels;
using Microsoft.AspNetCore.Diagnostics;
using PMPublicSite.Services;
using System.Net;
using Microsoft.AspNetCore.Authorization;
using PMPublicSite.Extensions;
using PMPublicSite.Common;

namespace PMPublicSite.Controllers
{

    public class HomeController : Controller
    {
        private readonly ILogger _logger;
        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public async Task<IActionResult> Index(string id)
        {
            try
            {
                string resourceId = ConfigVars.Instance.ResourceId;
                Console.WriteLine("resource id :{0}", resourceId);
                if (!string.IsNullOrEmpty(resourceId))
                {
                    ResourceViewModel resource = await AddonAPI.GetResource(resourceId);
                    if (!resource.IsNull())
                    {
                        var result = await AddonAPI.GetCategoryInfo(resourceId);
                        if (result != null && result.Count > 0)
                        {
                            ViewBag.Categories = result;
                            ViewBag.AlertMessage = null;
                        }
                    }
                    else
                    {
                        ViewBag.Categories = null;
                        ViewBag.AlertMessage = "Portfolio Manager is De-provisioned from your Heroku account. Please delete this App from your account as it will not work when it is not linked to a Portfolio Manager add-on.";
                    }
                }
                else
                {
                    ViewBag.Categories = null;
                    ViewBag.AlertMessage = "Portfolio Manager is De-provisioned from your Heroku account. Please delete this App from your account as it will not work when it is not linked to a Portfolio Manager add-on.";
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("ERROR: {0}", ex.Message);
                ViewBag.Categories = null;
                ViewBag.AlertMessage = null;

                if (Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") == Environments.Development)
                    _logger.LogError(ex.Message, ex);
                else
                    Console.WriteLine("ERROR: {0}", ex.Message);
            }
            return View();
        }

        public async Task<JsonResult> GetPublicApps(string id)
        {
            try
            {
                if (string.IsNullOrEmpty(id))
                {
                    return Json(new { Status = (int)HttpStatusCode.InternalServerError });
                }
                else
                {
                    var applications = await AddonAPI.GetAppList(id);
                    if (applications != null && applications.Count > 0)
                    {
                        return Json(new { Status = (int)HttpStatusCode.OK, apps = applications });
                    }
                    else
                    {
                        return Json(new { Status = (int)HttpStatusCode.NoContent });
                    }
                }
            }
            catch (Exception ex)
            {
                if (Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") == Environments.Development)
                    _logger.LogError(ex.Message, ex);
                else
                    Console.WriteLine("ERROR: {0}", ex.Message);
                return Json(new { Status = (int)HttpStatusCode.InternalServerError });
            }
        }

        public async Task<JsonResult> GetAppDetail(string id)
        {
            try
            {
                if (string.IsNullOrEmpty(id))
                {
                    return Json(new { Status = (int)HttpStatusCode.InternalServerError });
                }
                else
                {
                    var app = await AddonAPI.GetAppDetail(id);
                    if (app != null)
                    {
                        return Json(new { Status = (int)HttpStatusCode.OK, apps = app });
                    }
                    else
                    {
                        return Json(new { Status = (int)HttpStatusCode.NoContent });
                    }
                }
            }
            catch (Exception ex)
            {
                if (Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") == Environments.Development)
                    _logger.LogError(ex.Message, ex);
                else
                    Console.WriteLine("ERROR: {0}", ex.Message);
                return Json(new { Status = (int)HttpStatusCode.InternalServerError });
            }
        }


        [AllowAnonymous]
        public IActionResult Error()
        {
            var feature = HttpContext.Features.Get<IExceptionHandlerFeature>();
            var exception = feature?.Error;
            return View(new ErrorViewModel() { Code = HttpStatusCode.InternalServerError, Message = exception.Message });
        }
    }
}
