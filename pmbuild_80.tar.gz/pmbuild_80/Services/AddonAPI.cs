﻿using RestSharp;
using PMPublicSite.Helpers;
using System;
using System.Collections.Generic;
using System.Net;
using System.Threading;
using PMPublicSite.ViewModels;
using PMPublicSite.Common;
using Newtonsoft.Json;

namespace PMPublicSite.Services
{
    public static class AddonAPI
    {
        public static async Task<List<CategoryViewModel>> GetCategoryInfo(string id)
        {
            var request = new RestRequest();
            request.Resource = $"public/getpubliccategories?id={id}";
            request.Method = Method.Get;
            request.AddHeader("content-type", "application/json");

            var client = new RestClient(baseUrl: new Uri(ConfigVars.Instance.AddonAPIUrl));
            var httpResponse = await client.ExecuteAsync(request).ConfigureAwait(false);
            if (httpResponse != null && (httpResponse.StatusCode == HttpStatusCode.OK || httpResponse.StatusCode == HttpStatusCode.Created))
            {
                return JsonConvert.DeserializeObject<List<CategoryViewModel>>(httpResponse.Content);
            }
            return null;
        }

        public static async Task<ResourceViewModel> GetResource(string id)
        {
            var request = new RestRequest();
            request.Resource = $"public/getresource?id={id}";
            request.Method = Method.Get;
            request.AddHeader("content-type", "application/json");

            var client = new RestClient(baseUrl: new Uri(ConfigVars.Instance.AddonAPIUrl));
            var httpResponse = await client.ExecuteAsync(request).ConfigureAwait(false);
            if (httpResponse != null && (httpResponse.StatusCode == HttpStatusCode.OK || httpResponse.StatusCode == HttpStatusCode.Created))
            {
                return JsonConvert.DeserializeObject<ResourceViewModel>(httpResponse.Content);
            }
            return default(ResourceViewModel);
        }

        public static async Task<List<ApplicationViewModel>> GetAppList(string id)
        {
            var request = new RestRequest();
            request.Resource = $"public/getpublicapps?id={id}";
            request.Method = Method.Get;
            request.AddHeader("content-type", "application/json");

            var client = new RestClient(baseUrl: new Uri(ConfigVars.Instance.AddonAPIUrl));
            var httpResponse = await client.ExecuteAsync(request).ConfigureAwait(false);
            if (httpResponse != null && (httpResponse.StatusCode == HttpStatusCode.OK || httpResponse.StatusCode == HttpStatusCode.Created))
            {
                return JsonConvert.DeserializeObject<List<ApplicationViewModel>>(httpResponse.Content);
            }
            return null;
        }

        public static async Task<ApplicationViewModel> GetAppDetail(string id)
        {
            var request = new RestRequest();
            request.Resource = $"public/getappdetail?id={id}";
            request.Method = Method.Get;
            request.AddHeader("content-type", "application/json");

            var client = new RestClient(baseUrl: new Uri(ConfigVars.Instance.AddonAPIUrl));
            var httpResponse = await client.ExecuteAsync(request).ConfigureAwait(false);
            if (httpResponse != null && (httpResponse.StatusCode == HttpStatusCode.OK || httpResponse.StatusCode == HttpStatusCode.Created))
            {
                return JsonConvert.DeserializeObject<ApplicationViewModel>(httpResponse.Content);
            }
            return null;
        }
    }
}