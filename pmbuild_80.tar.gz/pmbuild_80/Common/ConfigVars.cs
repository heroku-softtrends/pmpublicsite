﻿using System;

namespace PMPublicSite.Common
{
    public sealed class ConfigVars
    {
        public string AddonAPIUrl = string.Empty;
        public string ResourceId = string.Empty;

        private ConfigVars()
        {
            ResourceId = Environment.GetEnvironmentVariable("ResourceId");
            AddonAPIUrl = Environment.GetEnvironmentVariable("AddonAPIUrl");
        }

        public static ConfigVars Instance { get { return ConfigVarInstance.Instance; } }

        private class ConfigVarInstance
        {
            static ConfigVarInstance()
            {
            }

            internal static readonly ConfigVars Instance = new ConfigVars();
        }
    }
}
