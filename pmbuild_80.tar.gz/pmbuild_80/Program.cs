using Microsoft.AspNetCore.CookiePolicy;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.VisualBasic;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using PMPublicSite.Helpers;

var builder = WebApplication.CreateBuilder(args);

//add services to the container
{
    builder.Services.AddAntiforgery(options => options.HeaderName = "X-XSRF-TOKEN");

    //set form options
    builder.Services.Configure<FormOptions>(options =>
    {
        options.ValueCountLimit = int.MaxValue; //default 1024
        options.ValueLengthLimit = int.MaxValue; //not recommended value
        options.MultipartBodyLengthLimit = long.MaxValue; //not recommended value
        options.KeyLengthLimit = int.MaxValue;
    });

    //set max file handle size
    builder.WebHost.ConfigureKestrel(serverOptions =>
    {
        serverOptions.Limits.MaxRequestBodySize = null;
        serverOptions.Limits.MaxRequestBufferSize = null;
        serverOptions.Limits.MaxResponseBufferSize = null;
    });

    //Add services to the container.
    builder.Services.AddRazorPages().AddSessionStateTempDataProvider();
    builder.Services
        .AddControllersWithViews()
        .AddNewtonsoftJson(options =>
        {
            options.SerializerSettings.NullValueHandling = NullValueHandling.Ignore;
            options.SerializerSettings.MissingMemberHandling = MissingMemberHandling.Ignore;
            options.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
            options.SerializerSettings.Formatting = Formatting.Indented;
            options.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();
            options.SerializerSettings.Converters.Add(new Newtonsoft.Json.Converters.StringEnumConverter());
        })
        .AddSessionStateTempDataProvider()
        .AddRazorRuntimeCompilation();

    builder.Services.Configure<CookiePolicyOptions>(options =>
    {
        //consent required
        options.CheckConsentNeeded = context => true;

        //prevent access from javascript 
        options.HttpOnly = HttpOnlyPolicy.Always;

        //If the URI that provides the cookie is HTTPS, 
        //cookie will be sent ONLY for HTTPS requests 
        options.Secure = CookieSecurePolicy.SameAsRequest;

        //refer "SameSite cookies" on website
        options.MinimumSameSitePolicy = SameSiteMode.None;
    });

    //Add framework services.
    builder.Services.AddCors();

    builder.Services.AddDistributedMemoryCache();
    //Add Session
    builder.Services.AddSession(options =>
    {
        options.IdleTimeout = TimeSpan.FromHours(5);
        options.Cookie.SecurePolicy = CookieSecurePolicy.Always;
        options.Cookie.HttpOnly = true;
        options.Cookie.IsEssential = true;
        options.Cookie.SameSite = SameSiteMode.None;
        options.Cookie.Name = ".PMSiteSessions";
    });
}

var app = builder.Build();
IHostApplicationLifetime lifetime = app.Lifetime;
IWebHostEnvironment env = app.Environment;
Utilities.AppServiceProvider = app.Services;

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseAuthentication();
app.UseCookiePolicy();
app.UseSession();
app.UseRouting();
app.UseCors(x => x
                .AllowAnyMethod()
                .AllowAnyHeader()
                .SetIsOriginAllowed(origin => true) // allow any origin
                .AllowCredentials()); // allow credentials
app.UseAuthorization();

app.MapControllerRoute(
        name: "default",
        pattern: "{controller=home}/{action=index}/{id?}");
app.MapControllerRoute(
        name: "defaultapi",
        pattern: "api/{controller}/{action}/{id?}");

app.Run();
